package com.example.pokemon;

import static android.app.PendingIntent.getActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CardsDetailMagic {


    /**
     * A simple {@link Fragment} subclass.
     * Use the {@link com.example.pokemon.CardsDetail#newInstance} factory method to
     * create an instance of this fragment.
     */
        // TODO: Rename parameter arguments, choose names that match
        // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
        private static final String ARG_POKE_ID = "pokeId";
        private static final String ARG_YGO_ID = "ygoId";
        private static final String ARG_MAGIC_ID = "magicId";
        private static final String ARG_COLOR_CV = "colorCardView";

        // TODO: Rename and change types of parameters
        private int pokeId;
        private int magicId;
        private static int ygoId;
        private static int colorCardView;

        public CardsDetailMagic() {
            // Required empty public constructor
        }

        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param pokeId Parameter 1.
         * @return A new instance of fragment PokemonDetail.
         */
        // TODO: Rename and change types and number of parameters
        public static com.example.pokemon.CardsDetail newInstance(int pokeId, int magicId) {
            com.example.pokemon.CardsDetail fragment = new com.example.pokemon.CardsDetail();
            Bundle args = new Bundle();
            args.putInt(ARG_POKE_ID, pokeId);
            args.putInt(ARG_MAGIC_ID, magicId);
            args.putInt(ARG_YGO_ID, ygoId);
            args.putInt(ARG_COLOR_CV, colorCardView);
            fragment.setArguments(args);
            return fragment;
        }


        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            if (getArguments() != null) {
                pokeId = getArguments().getInt(ARG_POKE_ID);
                magicId = getArguments().getInt(ARG_MAGIC_ID);
                ygoId = getArguments().getInt(ARG_YGO_ID);
                colorCardView = getArguments().getInt(ARG_COLOR_CV);
            }

            renderCards();
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            // Inflate the layout for this fragment
            return inflater.inflate(R.layout.fragment_detail, container, false);
        }

        private void renderCards() {
            Call<Magic> call = RetrofitClient.getInstance().getMyApi().getMagic(magicId);
            call.enqueue(new Callback<Magic>(){
                @Override
                public void onResponse(Call<Magic> call, Response<Magic> response) {
                    Magic magic = response.body();
                    TextView tvName = getActivity().findViewById(R.id.tvNameDetail);
                    TextView tvWeight = getActivity().findViewById(R.id.tvPokeWeightDetail);
                    TextView tvHeight = getActivity().findViewById(R.id.tvPokeHeightDetail);
                    TextView tvHP = getActivity().findViewById(R.id.tvPokeHP);
                    TextView tvAttack = getActivity().findViewById(R.id.tvPokeAttack);
                    TextView tvDefense = getActivity().findViewById(R.id.tvPokeDefense);
                    TextView tvSpDefense = getActivity().findViewById(R.id.tvPokeSpDefense);
                    TextView tvApAttack = getActivity().findViewById(R.id.tvPokeSpAttack);
                    TextView tvSpeed = getActivity().findViewById(R.id.tvPokeSpeed);
                    CardView cvPokemon = getActivity().findViewById(R.id.cardsDetail);
                    LinearLayout llFakeBackground = getActivity().findViewById(R.id.backFakeCardView);

                    cvPokemon.setCardBackgroundColor(colorCardView);
                    llFakeBackground.setBackgroundColor(colorCardView);

                    tvName.setText(magic.getName());
                    tvWeight.setText(magic.getWeight().toString());
                    tvHeight.setText(magic.getHeight().toString());
                    tvHP.setText(magic.getStat("hp").toString());
                    tvAttack.setText(magic.getStat("attack").toString());
                    tvDefense.setText(magic.getStat("defense").toString());
                    tvSpDefense.setText(magic.getStat("special-defense").toString());
                    tvApAttack.setText(magic.getStat("special-attack").toString());
                    tvSpeed.setText(magic.getStat("speed").toString());

                    String urlImage = magic.getSprites()
                            .getAsJsonObject("other")
                            .getAsJsonObject("official-artwork")
                            .getAsJsonPrimitive("front_default").getAsString();

                }



                @Override
                public void onFailure(Call<Magic> call, Throwable t) {
                    Log.d("TESTE", t.toString());
                }
            });
        }
    }
}
