package com.example.pokemon;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class YgoList extends Fragment {

    ArrayList<Ygo> ygos = new ArrayList<Ygo>();
    RecyclerView rvYgo;
    PokemonAdapter YgoAdapter;
    private YgoAdapter ygoAdapter;

    public YgoList() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cards_list, container, false);
    }

    @Override
    public void onResume() {
        super.onResume();

        rvYgo = getActivity().findViewById(R.id.rvCards);
        ygoAdapter = new YgoAdapter(ygos);
        RecyclerView.LayoutManager layout =
                new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
       rvYgo.setLayoutManager(layout);
        rvYgo.setAdapter(YgoAdapter);

        getYgoFromApi();
    }

    private void getYgoFromApi() {

        for (int i=0; i<10; i++) {
            int YgoId = generateRandom();
            Call<Ygo> call = RetrofitClient.getInstance().getMyApi().getYgo(YgoId);
            call.enqueue(new Callback<Ygo>() {
                @Override
                public void onResponse(Call<Ygo> call, Response<Ygo> response) {
                    Ygo ygoo = response.body();
                    ygos.add(ygoo);
                    YgoAdapter.notifyDataSetChanged();
                }

                @Override
                public void onFailure(Call<Ygo> call, Throwable t) {
                    Log.d("TESTE", t.toString());
                }
            });
        }

    }

    private int generateRandom() {
        int min = 0;
        int max = 800;

        return (int)Math.floor(Math.random()*(max-min+1)+min);
    }
}