package com.example.pokemon;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MagicList extends Fragment {

    ArrayList<Magic> magics = new ArrayList<Magic>();
    RecyclerView rvMagic;
   MagicAdapter MagicAdapter;

    public MagicList() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cards_list, container, false);
    }

    @Override
    public void onResume() {
        super.onResume();

        rvMagic = getActivity().findViewById(R.id.rvCards);
        MagicAdapter = new MagicAdapter(magics);
        RecyclerView.LayoutManager layout =
                new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvMagic.setLayoutManager(layout);
        rvMagic.setAdapter(MagicAdapter);

        getMagicFromApi();
    }

    private void getMagicFromApi() {

        for (int i=0; i<10; i++) {
            int magicId = generateRandom();
            Call<Magic> call = RetrofitClient.getInstance().getMyApi().getMagic(magicId);
            call.enqueue(new Callback<Magic>() {
                @Override
                public void onResponse(Call<Magic> call, Response<Magic> response) {
                    Magic magic = response.body();
                    magics.add(magic);
                    MagicAdapter.notifyDataSetChanged();
                }

                @Override
                public void onFailure(Call<Magic> call, Throwable t) {
                    Log.d("TESTE", t.toString());
                }
            });
        }

    }

    private int generateRandom() {
        int min = 0;
        int max = 800;

        return (int)Math.floor(Math.random()*(max-min+1)+min);
    }
}