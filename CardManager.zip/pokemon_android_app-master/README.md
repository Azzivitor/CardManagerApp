# pokemon_android_app

A simple pokemon master-detail app. 

The app use Retrofit, RecyclerView, Images, Picasso, CardView, simple interface elements, complex list interface, Palette.
